<?php
$conn = mysqli_connect('localhost', 'u399445477_hassan', 'Rawaati71168714', 'u399445477_store');
if (!$conn) {
    echo 'Error' . ' ' . mysqli_connect_error();
} /*else
     echo 'connected'; */