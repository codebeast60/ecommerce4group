<?php 
$con = mysqli_connect('localhost', 'u399445477_hassan', 'Rawaati71168714', 'u399445477_store');
?>